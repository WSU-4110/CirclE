
--**************************************************************************************
-- Part 1 Question 4
--**************************************************************************************
RAISERROR (N'This is Part %d Question %s %d.', -- Message text.
10, -- Severity,
1, -- State,
1, --First Argument
N'number', -- second argument.
1); -- third argument.
-- The message text returned is: This is message number 5.
GO
USE Student_Grade_Report;
GO

-- Insert test data into Students table
INSERT INTO Students (StudentID, StudentName, StudentNo, Major)
VALUES
    (1, 'John Smith', 'S12345', 'Computer Science'),
    (2, 'Jane Doe', 'S67890', 'Mathematics'),
    (3, 'Robert Johnson', 'S24680', 'Physics'),
    (4, 'Emily White', 'S13579', 'Biology');

-- Insert test data into Instructors table
INSERT INTO Instructors (InstructorNo, InstructorName, InstructorLocation)
VALUES
    (101, 'Dr. James Brown', 'Room A-101'),
    (102, 'Prof. Sarah Wilson', 'Room B-205'),
    (103, 'Dr. Michael Davis', 'Room C-301');

-- Insert test data into Courses table
INSERT INTO Courses (CourseNo, CourseName, InstructorNo)
VALUES
    (501, 'Database Management', 101),
    (502, 'Calculus I', 102),
    (503, 'Quantum Mechanics', 103),
    (504, 'Genetics', 101);

-- Insert test data into Grades table
INSERT INTO Grades (GradeID, StudentID, CourseNo, Grade)
VALUES
    (1001, 1, 501, 'A'),
    (1002, 2, 502, 'B+'),
    (1003, 3, 503, 'A-'),
    (1004, 4, 504, 'B'),
    (1005, 1, 502, 'A'),
    (1006, 2, 503, 'B'),
    (1007, 3, 504, 'A'),
    (1008, 4, 501, 'C');

