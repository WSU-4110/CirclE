-- Create the StudentGradeReport database
--**************************************************************************************
-- Part 1 Question 3
--**************************************************************************************
RAISERROR (N'This is Part %d Question %s %d.', -- Message text.
10, -- Severity,
1, -- State,
1, --First Argument
N'number', -- second argument.
1); -- third argument.
-- The message text returned is: This is message number 5.
GO
CREATE DATABASE Student_Grade_Report;
GO

-- Use the StudentGradeReport database
USE Student_Grade_Report;
GO

-- Create the Students table
CREATE TABLE Students (
    StudentID INT PRIMARY KEY,
    StudentName NVARCHAR(100),
    StudentNo NVARCHAR(20),
    Major NVARCHAR(50)
);
GO

-- Create the Instructors table
CREATE TABLE Instructors (
    InstructorNo INT PRIMARY KEY,
    InstructorName NVARCHAR(100),
    InstructorLocation NVARCHAR(100)
);
GO

-- Create the Courses table
CREATE TABLE Courses (
    CourseNo INT PRIMARY KEY,
    CourseName NVARCHAR(100),
    InstructorNo INT,
    FOREIGN KEY (InstructorNo) REFERENCES Instructors(InstructorNo)
);
GO

-- Create the Grades table
CREATE TABLE Grades (
    GradeID INT PRIMARY KEY,
    StudentID INT,
    CourseNo INT,
    Grade CHAR(2),
    FOREIGN KEY (StudentID) REFERENCES Students(StudentID),
    FOREIGN KEY (CourseNo) REFERENCES Courses(CourseNo)
);
GO
